﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_Follow : MonoBehaviour 
{
	public GameObject character;
	public float cameraDistance = 30.0f;

	[SerializeField] float leftLimit;
	[SerializeField] float rightLimit;
	[SerializeField] float bottomLimit;
	[SerializeField] float topLimit;

	void Awake()
	{
		//GetComponent<UnityEngine.Camera>().orthographicSize = ((Screen.height / 2) / cameraDistance);
	}

	void FixedUpdate()
	{
		transform.position = new Vector3(character.transform.position.x, transform.position.y, transform.position.z);
	}

	void Update()
	{
		transform.position = new Vector3
		(
			Mathf.Clamp(transform.position.x, leftLimit, rightLimit),
			Mathf.Clamp(transform.position.y, topLimit, bottomLimit),
			transform.position.z
		);
	}
}
