﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EFDCharacterController : MonoBehaviour 
{
	public float speed;

	public Transform groundPos;
	public float jumpForce;
	private bool isGrounded = false;
	public float checkRadius;
	public LayerMask whatIsGround;
	private bool isJumping = false;
	private Rigidbody2D rb2d;
	private Animator anim;

	void Start ()
	{
		rb2d = GetComponent<Rigidbody2D> ();
		anim = GetComponent<Animator> ();
	}

	private void Update () 
	{
		if (Input.GetButtonDown("Jump") || Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))
		{
			isJumping = true;
		}
		else if (isGrounded && isJumping)
			{
				rb2d.velocity = Vector2.up * jumpForce;
				isJumping = false;
			}
	}

	void FixedUpdate ()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");
		Vector2 movement = new Vector2 (moveHorizontal, moveVertical);

		isGrounded = Physics2D.OverlapCircle(groundPos.position, checkRadius, whatIsGround);

		if (moveHorizontal < 0)
			{
				rb2d.velocity = new Vector2(moveHorizontal * speed, rb2d.velocity.y);
				transform.eulerAngles = new Vector3(0, 180, 0);
			}
		else if (moveHorizontal > 0)
			{
				rb2d.velocity = new Vector2(moveHorizontal * speed, rb2d.velocity.y);
				transform.eulerAngles = new Vector3(0, 0, 0);
			}

		Debug.Log("Am I on the ground" + isGrounded);
		anim.SetFloat("Speed", Mathf.Abs(moveHorizontal));
	}

}

	